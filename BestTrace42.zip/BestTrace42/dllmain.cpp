// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include "wininet.h"
#include <string>

#define BASE_URL "http://ipip.map.dn42/whois"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
        case DLL_PROCESS_ATTACH:
        {
            UINT EULA_READ = ::GetPrivateProfileIntA("EULA", "Read", 0, ".\\EULA.ini");
            if (EULA_READ == 0) {
                if (::MessageBox(NULL, _T("This is IPIP.NET BestTrace <MODIFIED> by iEdon\r\nCopyright (C) IPIP.NET\r\n\r\nThis tool brings official good traceroute experience with 3rd party DN42 support injection.\r\nThis software comes with no warranty because the original one is not open source.\r\n\r\n*** USE IT AT YOUR OWN RISK ***\r\n\r\nHave questions?\r\nContact me:  IRC: iedon@hackint\r\nThank you!"), _T("Welcome"), MB_YESNO | MB_ICONASTERISK) == IDYES) {
                    ::WritePrivateProfileStringA("EULA", "Read", "1", ".\\EULA.ini");
                }
                else {
                    ::MessageBox(NULL, _T("You MUST agree the EULA before you can use this tool.\r\n\r\nHave questions?\r\nContact me:  IRC: iedon@hackint\r\nThank you!"), _T("Oops"), MB_ICONERROR);
                    ::ExitProcess(EXIT_FAILURE);
                }
                
            }
        }
        break;
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
        case DLL_PROCESS_DETACH:
            break;
    }
    return TRUE;
}


__declspec(dllexport) HINTERNET WINAPI DN42_InternetOpenUrlA(
    HINTERNET   hInternet,
    LPCSTR      lpszUrl,
    LPCSTR      lpszHeaders,
    DWORD       dwHeadersLength,
    DWORD       dwFlags,
    DWORD_PTR   dwContext)
{
    HINTERNET ret = NULL;
    const char* finalURL = lpszUrl;
    std::string originalURL(lpszUrl);
    if (originalURL.find("ip=172.") != std::string::npos ||
        originalURL.find("ip=10.") != std::string::npos ||
        originalURL.find("ip=fd") != std::string::npos)
    {
        std::string newURL(BASE_URL);
        size_t pos = originalURL.find("https://btapi.ipip.net/host/info");
        if (pos != std::string::npos) {
            newURL.append(originalURL.substr(pos + sizeof("https://btapi.ipip.net/host/info") - 1));
            finalURL = newURL.c_str();
        }
    }
    else {
        size_t pos = originalURL.find("https://clientapi.ipip.net/asn/info?asn=AS");
        if (pos != std::string::npos) {
            std::string asnString = originalURL.substr(pos + sizeof("https://clientapi.ipip.net/asn/info?asn=AS") - 1);
            LONGLONG asn = atoll(asnString.c_str());
            if (asn >= 65512 && asn <= 65534 || asn >= 4200000000) {
                std::string newURL(BASE_URL);
                newURL.append("?asn=AS").append(asnString);
                finalURL = newURL.c_str();
            }
        }
    }
    ret = ::InternetOpenUrlA(hInternet, finalURL, lpszHeaders, dwHeadersLength, dwFlags, dwContext);
    return ret;
}
